from SoundCloudR import application, db

db.create_all()